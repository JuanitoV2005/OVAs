const respuestasTeoria = {
    "q1-q1": { valor: "Verdadero" },
    "q1-q2": { valor: "4" },
    "q1-q3": { valor: "long" },
    "q1-q4": { valor: "-100" }
};
